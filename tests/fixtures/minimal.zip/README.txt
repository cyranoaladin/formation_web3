RBK minimal fixture
